
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ContactDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const ContactDialog = ({ open, onOpenChange }: ContactDialogProps) => {
  const contacts = [
    {
      name: "Telegram Channel",
      url: "https://t.me/sotmel_slot2D3D",
      color: "bg-[#0088cc]",
    },
    {
      name: "Telegram Account",
      url: "https://t.me/sotmel_O",
      color: "bg-[#0088cc]",
    },
    {
      name: "Viber",
      url: "https://msng.link/o?959448800472=vi",
      color: "bg-[#665CAC]",
    },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#1A1F2C] text-white border-[#9b87f5]">
        <DialogHeader>
          <DialogTitle className="text-center text-xl text-white mb-4">
            ဆက်သွယ်ရန်
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col space-y-3">
          {contacts.map((contact) => (
            <a
              key={contact.name}
              href={contact.url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full"
            >
              <Button
                className={`w-full ${contact.color} hover:opacity-90 text-white`}
                size="lg"
              >
                {contact.name}
              </Button>
            </a>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ContactDialog;
