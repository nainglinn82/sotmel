import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import ContactDialog from '@/components/ContactDialog';
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const { toast } = useToast();

  const handleLogin = () => {
    toast({
      variant: "destructive",
      title: "Password မှားနေပါသဖြင့် ဆက်သွယ်ရန် ကို နှိပ်ပါ",
      duration: 3000,
    });
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center px-4 py-8">
      <img 
        src="/lovable-uploads/b186d104-dde8-4b33-807e-55b5f7c2f826.png"
        alt="Game Logo"
        className="w-48 h-48 mb-8 rounded-full"
      />
      
      <div className="w-full max-w-md space-y-4">
        <div className="relative">
          <Input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full bg-[#1A1F2C] text-white border-[#9b87f5] pl-12"
            placeholder="ဖုန်းနံပါတ်"
          />
          <span className="absolute left-4 top-1/2 transform -translate-y-1/2">
            📱
          </span>
        </div>

        <div className="relative">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#1A1F2C] text-white border-[#9b87f5] pl-12"
            placeholder="လျှို့ဝှက်နံပါတ်"
          />
          <span className="absolute left-4 top-1/2 transform -translate-y-1/2">
            🔒
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox 
            id="terms" 
            checked={agreed}
            onCheckedChange={(checked) => setAgreed(checked as boolean)}
            className="border-[#9b87f5]"
          />
          <label htmlFor="terms" className="text-white text-sm">
            I agree Sotmel Terms
          </label>
        </div>

        <Button 
          onClick={handleLogin}
          className="w-full bg-[#8B0000] hover:bg-[#A52A2A] text-white"
          size="lg"
        >
          အကောင့်ဝင်ရန်
        </Button>

        <Button 
          onClick={() => setContactOpen(true)}
          className="w-full bg-green-600 hover:bg-green-700 text-white"
          size="lg"
        >
          contact(ဆက်သွယ်ရန်)
        </Button>
      </div>

      <ContactDialog 
        open={contactOpen} 
        onOpenChange={setContactOpen}
      />
    </div>
  );
};

export default Index;
