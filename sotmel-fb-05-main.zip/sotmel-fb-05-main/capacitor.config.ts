
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.fb1a81b324b94532bcfda4770cedbc80',
  appName: 'myanmar-social-links',
  webDir: 'dist',
  server: {
    url: 'https://fb1a81b3-24b9-4532-bcfd-a4770cedbc80.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  android: {
    buildOptions: {
      minSdkVersion: 22,
      targetSdkVersion: 33,
    }
  }
};

export default config;
